#import "EAGLView.h"
#import "LegacyViews.h"
#import "MainMode.h"
#import "OtamatoneCore.h"
#import "OtamaReplay.h"
#import <CoreMotion/CoreMotion.h>
#include <math.h>
@interface EAGLView()
@property(nonatomic,strong)MainMode*mainMode;@property(nonatomic,strong)CADisplayLink*animationTimer;@property(nonatomic,strong)CMMotionManager*motion;@property(nonatomic,strong)NSMutableDictionary<NSValue*,NSNumber*>*touchIDs;@property(nonatomic)int nextTouchID;@property(nonatomic,strong)NSMutableDictionary<NSString*,UIImage*>*imageCache;@property(nonatomic)BOOL enableUpdate;@property(nonatomic,strong)OtamaReplay*pendingRecording;
@end
@implementation EAGLView
+(Class)layerClass{return CALayer.class;}
-(instancetype)initWithFrame:(CGRect)f{if((self=[super initWithFrame:f]))[self Initialize];return self;}
-(instancetype)initWithCoder:(NSCoder*)c{if((self=[super initWithCoder:c]))[self Initialize];return self;}
-(void)awakeFromNib{[super awakeFromNib];[self InitGUI];}
-(void)Initialize{if(_mainMode)return;self.multipleTouchEnabled=YES;self.opaque=YES;self.backgroundColor=UIColor.blackColor;self.animationInterval=1.0/30;self.enableUpdate=YES;self.touchIDs=[NSMutableDictionary dictionary];self.nextTouchID=1;self.imageCache=[NSMutableDictionary dictionary];ACRInitialize();_mainMode=[MainMode new];_mainMode.view=self;[_mainMode Initialize];[self setupMotion];}
-(void)InitGUI{
    // All of these are top-level objects from the original MainWindow.nib.
    // Keep them detached until the same original selector opens them.
    NSArray<UIView*> *archivedViews=@[self.NameEntry,self.HtmlView,self.pAlert,self.viewSetting,self.viewSettingMelody,self.viewMusicList,self.viewMusicListMelody,self.viewMenu,self.viewMenuHeader,self.viewMenuHeaderMelody,self.viewTitleBG,self.viewTitleBGMelody,self.viewTitleOtama,self.viewTitleOtamaMelody];
    for(UIView *v in archivedViews){if(v.superview==self)[v removeFromSuperview];v.hidden=YES;v.alpha=1;}
    [self OpenTitle];[self startAnimation];
}
-(MainMode*)GetMainMode{return self.mainMode;}
-(void)setupMotion{self.motion=[CMMotionManager new];self.motion.accelerometerUpdateInterval=1.0/60;if(self.motion.accelerometerAvailable){[self.motion startAccelerometerUpdatesToQueue:NSOperationQueue.mainQueue withHandler:^(CMAccelerometerData*d,NSError*e){if(d&&!e)ACRSetAcc((float)d.acceleration.x,(float)d.acceleration.y,(float)d.acceleration.z);}];}}
-(void)setAnimationInterval:(NSTimeInterval)v{_animationInterval=MAX(1.0/120,v);if(self.animationTimer){[self stopAnimation];[self startAnimation];}}
-(void)startAnimation{if(self.animationTimer)return;self.animationTimer=[CADisplayLink displayLinkWithTarget:self selector:@selector(drawView)];self.animationTimer.preferredFramesPerSecond=30;[self.animationTimer addToRunLoop:NSRunLoop.mainRunLoop forMode:NSRunLoopCommonModes];}
-(void)stopAnimation{[self.animationTimer invalidate];self.animationTimer=nil;}
-(void)SetEnableUpdate:(BOOL)e{self.enableUpdate=e;}
-(void)drawView{if(self.enableUpdate)[self.mainMode Update];[self.mainMode Render];[self setNeedsDisplay];}
-(void)dealloc{[self stopAnimation];[self.motion stopAccelerometerUpdates];[self.mainMode Quit];}

#pragma mark - original NIB view presentation
-(void)legacyShowView:(UIView*)v frame:(CGRect)frame{if(!v)return;v.transform=CGAffineTransformIdentity;v.frame=frame;v.hidden=NO;v.alpha=1;if(v.superview!=self)[self addSubview:v];else[self bringSubviewToFront:v];}
-(void)legacyHideView:(UIView*)v{if(!v)return;v.hidden=YES;[v removeFromSuperview];}
-(BOOL)isMelodyUI{return self.mainMode.mode==OtamaModeMelody;}
-(void)OpenTitle{BOOL m=[self isMelodyUI];UIView*bg=m?self.viewTitleBGMelody:self.viewTitleBG;UIView*fg=m?self.viewTitleOtamaMelody:self.viewTitleOtama;[self legacyShowView:bg frame:bg.bounds];[self legacyShowView:fg frame:fg.bounds];}
-(void)CloseTitle{UIView*bg=self.viewTitleBG.superview?self.viewTitleBG:self.viewTitleBGMelody;UIView*fg=self.viewTitleOtama.superview?self.viewTitleOtama:self.viewTitleOtamaMelody;[UIView animateWithDuration:.20 animations:^{bg.alpha=0;fg.alpha=0;} completion:^(__unused BOOL f){[self legacyHideView:bg];[self legacyHideView:fg];bg.alpha=fg.alpha=1;}];}
-(void)DeleteTitle{[self legacyHideView:self.viewTitleBG];[self legacyHideView:self.viewTitleBGMelody];[self legacyHideView:self.viewTitleOtama];[self legacyHideView:self.viewTitleOtamaMelody];}
-(void)OpenMenu{[self.mainMode userDidInteract];BOOL m=[self isMelodyUI];UIView*h=m?self.viewMenuHeaderMelody:self.viewMenuHeader;[self legacyShowView:h frame:CGRectMake(0,0,320,151)];[self legacyShowView:self.viewMenu frame:CGRectMake(0,140,320,340)];self.mainMode.mode=OtamaModeMenu;}
-(void)CloseMenu{[UIView animateWithDuration:.16 animations:^{self.viewMenu.alpha=0;self.viewMenuHeader.alpha=0;self.viewMenuHeaderMelody.alpha=0;} completion:^(__unused BOOL f){[self CloseMenuEnd];}];}
-(void)CloseMenuEnd{[self legacyHideView:self.viewMenu];[self legacyHideView:self.viewMenuHeader];[self legacyHideView:self.viewMenuHeaderMelody];self.viewMenu.alpha=self.viewMenuHeader.alpha=self.viewMenuHeaderMelody.alpha=1;if(self.mainMode.mode==OtamaModeMenu)self.mainMode.mode=OtamaModeGame;}
-(void)CloseMenuToPlayList{[self CloseMenuEnd];[self OpenMusicList];}
-(void)OpenMusicList{[self CloseMenuEnd];[self.viewMusicList Initialize];[self legacyShowView:self.viewMusicList frame:CGRectMake(0,0,320,480)];self.mainMode.mode=OtamaModeFileList;}
-(void)OpenMusicList2{[self CloseMenuEnd];[self.viewMusicListMelody Initialize];[self legacyShowView:self.viewMusicListMelody frame:CGRectMake(0,0,320,480)];self.mainMode.mode=OtamaModeMelody;}
-(void)RemoveMusicList{[self legacyHideView:self.viewMusicList];[self legacyHideView:self.viewMusicListMelody];}
-(void)CloseMusicListToMenu{[self RemoveMusicList];self.mainMode.mode=OtamaModeGame;[self OpenMenu];}
-(void)CloseMusicListToMelody{[self RemoveMusicList];self.mainMode.mode=OtamaModeMelody;}
-(void)OpenHowTo{[self legacyShowView:self.HtmlView frame:CGRectMake(0,0,320,480)];[self.HtmlView SetURL:[NSString stringWithFormat:@"howto_%@",[NSLocale.preferredLanguages.firstObject hasPrefix:@"ja"]?@"jp":@"eng"]];self.HtmlView.alpha=0;[UIView animateWithDuration:.18 animations:^{self.HtmlView.alpha=1;}];}
-(void)OpenAbout{[self legacyShowView:self.HtmlView frame:CGRectMake(0,0,320,480)];[self.HtmlView SetURL:[NSString stringWithFormat:@"about_%@",[NSLocale.preferredLanguages.firstObject hasPrefix:@"ja"]?@"jp":@"eng"]];self.HtmlView.alpha=0;[UIView animateWithDuration:.18 animations:^{self.HtmlView.alpha=1;}];}
-(void)OpenNameEntry{[self legacyShowView:self.NameEntry frame:CGRectMake(0,0,320,480)];[self.NameEntry Setup:0 :0];}
-(void)OpenAlert:(NSInteger)type{[self legacyShowView:self.pAlert frame:CGRectMake(0,0,320,480)];self.pAlert.alertType=type;[self.pAlert SetMessage:type?@"Unable to save recording.":@"Are you sure?"];if(type)[self.pAlert SetIconB];else[self.pAlert SetIconA];self.pAlert.alpha=0;[UIView animateWithDuration:.15 animations:^{self.pAlert.alpha=1;}];}
-(void)InitAlert{self.pAlert.hidden=YES;}
-(void)OpenSetting:(NSInteger)v :(NSInteger)o :(NSInteger)f :(NSInteger)b :(NSInteger)s :(NSInteger)r :(BOOL)melody{[self CloseMenuEnd];if(melody){[self legacyShowView:self.viewSettingMelody frame:CGRectMake(0,0,320,480)];[self.viewSettingMelody SetDefaultValue:v :o :f :b :s :r];}else{[self legacyShowView:self.viewSetting frame:CGRectMake(0,0,320,480)];[self.viewSetting SetDefaultValue:v :o :f :b :s];}self.mainMode.mode=OtamaModeSetting;}
-(void)InitSettingView{[self OpenSetting:(NSInteger)lrintf(SettingGetVolume()*100) :SettingGetOctave() :SettingIsFollow() :SettingState()->hideFukidashi :SettingGetSkin() :SettingState()->recordHoldMode :NO];}

#pragma mark - exact asset-backed game canvas
-(UIImage*)img:(NSString*)n{UIImage*i=self.imageCache[n];if(!i){i=[UIImage imageNamed:n];if(i)self.imageCache[n]=i;}return i;}
-(void)drawImage:(UIImage*)im crop:(CGRect)cr dest:(CGRect)d{if(!im)return;CGRect limit=CGRectMake(0,0,im.size.width,im.size.height);cr=CGRectIntersection(cr,limit);if(CGRectIsEmpty(cr))return;CGImageRef cg=CGImageCreateWithImageInRect(im.CGImage,cr);if(cg){[[UIImage imageWithCGImage:cg scale:im.scale orientation:UIImageOrientationUp]drawInRect:d];CGImageRelease(cg);}}
-(NSString*)skinSuffix{switch(SettingGetSkin()){case 1:return @"b";case 2:return @"red";case 3:return @"yellow";case 4:return @"blue";default:return @"w";}}
-(void)drawRect:(CGRect)r{CGContextRef c=UIGraphicsGetCurrentContext();[UIColor.blackColor setFill];CGContextFillRect(c,self.bounds);if(self.mainMode.mode!=OtamaModeTitle)[self drawOriginalGameApproximation];}
-(void)drawOriginalGameApproximation{
    // The menus/title/settings are now the literal original NIB. This remaining
    // path corresponds to the old OpenGL gameplay layer and uses its original
    // sprite sheets/assets while the ARMv7 renderer is translated incrementally.
    UIImage*bg=[self img:@"main_bg.png"];if(bg)for(CGFloat x=0;x<320;x+=MAX(1,bg.size.width))[bg drawInRect:CGRectMake(x,0,bg.size.width,480)];
    NSString*s=[self skinSuffix];UIImage*flag=[self img:[NSString stringWithFormat:@"otama_flag_%@.png",s]];if(flag){NSInteger f=MAX(0,MIN(7,self.mainMode.flagFrame));[self drawImage:flag crop:CGRectMake(0,f*115,400,115) dest:CGRectMake(-40,15,400,115)];}
    UIImage*body=[self img:[NSString stringWithFormat:@"otama_body_%@.png",s]];if(body)[self drawImage:body crop:CGRectMake(0,0,256,330) dest:CGRectMake(32,116,256,330)];
    UIImage*head=[self img:[NSString stringWithFormat:@"otama_head_%@.png",s]];if(head){CGFloat g=self.mainMode.mouth*34;[self drawImage:head crop:CGRectMake(20,5,280,142) dest:CGRectMake(20,218-g*.18,280,142)];[self drawImage:head crop:CGRectMake(20,145,280,140) dest:CGRectMake(20,326+g*.55,280,140)];NSInteger er=(self.mainMode.replaying||self.mainMode.recording)?1:0;CGRect e1=er?CGRectMake(332,105,36,35):CGRectMake(332,20,36,40),e2=er?CGRectMake(392,105,36,35):CGRectMake(392,20,36,40);[self drawImage:head crop:e1 dest:CGRectMake(113,260-g*.18,23,23)];[self drawImage:head crop:e2 dest:CGRectMake(185,260-g*.18,23,23)];}
    UIImage*menu=[self img:@"bot_menu_off.png"];if(menu)[menu drawInRect:CGRectMake(258,8,58,43)];if(!SettingState()->hideFukidashi&&self.mainMode.playing){UIImage*b=[self img:@"fukidashi_1.png"];if(b)[b drawInRect:CGRectMake(184,64,126,121)];}
}

#pragma mark - original touch pipeline
-(NSNumber*)touchID:(UITouch*)t create:(BOOL)c{NSValue*k=[NSValue valueWithNonretainedObject:t];NSNumber*n=self.touchIDs[k];if(!n&&c){n=@(self.nextTouchID++);self.touchIDs[k]=n;}return n;}
-(void)feed:(NSSet<UITouch*>*)ts phase:(int)ph{for(UITouch*t in ts){CGPoint p=[t locationInView:self];NSNumber*n=[self touchID:t create:ph==0];if(!n)continue;if(ph==0)ACRBegin(n.intValue,p.x,p.y);else if(ph==1)ACRMove(n.intValue,p.x,p.y);else{ACREnd(n.intValue,p.x,p.y);[self.touchIDs removeObjectForKey:[NSValue valueWithNonretainedObject:t]];}}[self updateInstrument];}
-(void)touchesBegan:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e{if(self.mainMode.mode==OtamaModeTitle){[self CloseTitle];[self.mainMode SetModeNoFade:OtamaModeGame];return;}for(UITouch*x in t){CGPoint p=[x locationInView:self];if(p.x>=245&&p.y<=68){[self OpenMenu];return;}}[self feed:t phase:0];}
-(void)touchesMoved:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e{[self feed:t phase:1];}
-(void)touchesEnded:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e{[self feed:t phase:2];}
-(void)touchesCanceled:(NSSet<UITouch*>*)t withEvent:(UIEvent*)e{[self feed:t phase:2];}
-(void)CheckCursor:(id)a :(id)b{}
-(void)updateInstrument{const ACRCursor*pitch=NULL,*m[2]={0};int mc=0;for(int i=0;i<4;i++){const ACRCursor*c=ACRGetCursor(i);if(!c||!c->active||c->ended)continue;if(c->y>200&&mc<2)m[mc++]=c;if(c->x>=92&&c->x<=228&&c->y>=65&&c->y<=330)if(!pitch||c->y<pitch->y)pitch=c;}float mv=self.mainMode.mouth;if(mc>=2){float d=hypotf(m[0]->x-m[1]->x,m[0]->y-m[1]->y);mv=fmaxf(0,fminf(1,(d-18)/145));}else if(mc==1&&m[0]->y>300&&m[0]->x>=96&&m[0]->x<=223)mv=fmaxf(0,fminf(1,(m[0]->y-300)/145));if(pitch){float t=fmaxf(0,fminf(1,(330-pitch->y)/265)),semis=t*24-12,p=powf(2,semis/12);[self.mainMode userInputPitch:p mouth:mv active:YES];}else[self.mainMode userInputPitch:self.mainMode.pitch mouth:mv active:NO];}

#pragma mark - recording / music selectors retained from original
-(void)promptSaveReplay:(OtamaReplay*)r{if(!r)return;self.pendingRecording=r;[self OpenNameEntry];}
-(void)StopMusic{[self.mainMode stopMelodyNative];}
-(void)setMusic:(NSInteger)i{[self.mainMode setMelodyIndexNative:i];}
-(void)SetMusicIndex01{[self setMusic:0];}-(void)SetMusicIndex02{[self setMusic:1];}-(void)SetMusicIndex03{[self setMusic:2];}-(void)SetMusicIndex04{[self setMusic:3];}-(void)SetMusicIndex05{[self setMusic:4];}-(void)SetMusicIndex06{[self setMusic:5];}-(void)SetMusicIndex07{[self setMusic:6];}-(void)SetMusicIndex08{[self setMusic:7];}-(void)SetMusicIndex09{[self setMusic:8];}-(void)SetMusicIndex10{[self setMusic:9];}-(void)SetMusicIndex11{[self setMusic:10];}
-(NSArray*)GetFileList{return OtamaUserReplayURLs();}-(NSArray*)GetFileNameList{NSMutableArray*a=[NSMutableArray array];for(OtamaReplay*r in self.mainMode.availableUserReplays)[a addObject:r.name?:@""];return a;}-(NSInteger)GetFileSkinID:(NSInteger)i{NSArray<OtamaReplay*>*a=self.mainMode.availableUserReplays;if(i<0||i>=(NSInteger)a.count)return 0;OtamaReplay*r=a[(NSUInteger)i];return r.skin;}-(void)LoadFileList{}-(void)CheckSave:(id)x :(NSInteger)y{}-(NSInteger)GetWebViewXPos{return 0;}-(void)SetIndicator{}-(void)DeleteIndicator{}-(void)layoutSubviews{[super layoutSubviews];}-(BOOL)createFramebuffer{return YES;}-(void)destroyFramebuffer{}-(void)Render{}-(void)Update{}-(void)Quit{}
@end
