#import <UIKit/UIKit.h>
#import "LegacyViews.h"
int main(int argc,char*argv[]){
    @autoreleasepool{
        OtamaRegisterLegacyMenuClass();
        // Match the 2010 executable: UIApplicationMain gets no delegate class.
        // NSMainNibFile=MainWindow instantiates GameProjectAppDelegate and the
        // complete original archived interface.
        return UIApplicationMain(argc,argv,nil,nil);
    }
}
