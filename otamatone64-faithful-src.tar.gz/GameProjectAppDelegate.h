#import <UIKit/UIKit.h>
@class EAGLView;
@interface GameProjectAppDelegate:UIResponder<UIApplicationDelegate>
@property(nonatomic,strong)IBOutlet UIWindow *window;
@property(nonatomic,strong)IBOutlet EAGLView *glView;
-(void)ResetAccelerometer;
@end
